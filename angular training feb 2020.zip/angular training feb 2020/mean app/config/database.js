module.exports = {
  // configure the code below with your username, password and mlab database information
  database: 'mongodb://admin:admin@cluster0-shard-00-00-n3opj.mongodb.net:27017,cluster0-shard-00-01-n3opj.mongodb.net:27017,cluster0-shard-00-02-n3opj.mongodb.net:27017/Fidelity?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin&retryWrites=true&w=majority',   //prod
  //database: 'mongodb://localhost:27017/meanauth',    //dev
  secret: 'yoursecret'
}
