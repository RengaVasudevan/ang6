export class Register {
    username: string;
    name: string;
    password: string;
    email: string;
}
