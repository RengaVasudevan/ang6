export class LoginResponse {
    success: boolean;
    token: string;
    user: User;
}

class User{
    id: string;
    name: string;
    username: string;
    email; string;
}
