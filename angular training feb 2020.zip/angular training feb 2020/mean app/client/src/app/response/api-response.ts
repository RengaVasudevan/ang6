export class ApiResponse {
    msg: string;
    success: boolean;
}
