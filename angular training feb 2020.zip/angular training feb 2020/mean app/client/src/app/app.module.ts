import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthService } from './service/auth.service';
import { TokenInterceptorComponent } from './interceptor/token-interceptor/token-interceptor.component';
import { LoginService } from './service/login.service';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AuthGuardComponent } from './auth-guard/auth-guard.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    LandingPageComponent,
    LoginComponent,
    RegisterComponent,
    DashboardComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [ AuthService, LoginService, {
    provide: HTTP_INTERCEPTORS,
    useClass: TokenInterceptorComponent,
    multi: true
  }, AuthGuardComponent ],
  bootstrap: [AppComponent]
})
export class AppModule { }
