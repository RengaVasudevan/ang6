import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Register } from '../model/register';
import { Observable } from 'rxjs/index';
import { ApiResponse } from '../response/api-response';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http: HttpClient) { }

  // uri : /users/register
  // accept register object
  // visiblity : public 
  // error specs
   registerUser(user: Register) : Observable<ApiResponse>{

    let headers =  new HttpHeaders();
    headers.append("Content-Type", "application/json");
    return this.http
    .post<ApiResponse>('http://localhost:8080/users/register', user, {headers: headers});
    

   }
}
