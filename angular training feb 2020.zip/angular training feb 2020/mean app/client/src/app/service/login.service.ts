import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/index';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { LoginResponse } from '../response/login-response';
import { Register } from '../model/register';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private http: HttpClient) { }

  // uri : /users/register
  // accept register object
  // visiblity : public 
  // error specs
   loginUser(user: Register) : Observable<LoginResponse>{

    let headers =  new HttpHeaders();
    headers.append("Content-Type", "application/json");
    return this.http
    .post<LoginResponse>('http://localhost:8080/users/authenticate', user, {headers: headers});
    

   }
}
