import { Component, OnInit } from '@angular/core';
import { Register } from '../model/register';
import { AuthService } from '../service/auth.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {


  register : Register =  new Register();

  constructor(private authService : AuthService, private router: Router) { }

  ngOnInit() {
  }

  onRegisterSubmit() {
  
    console.log(JSON.stringify(this.register));
    this.authService.registerUser(this.register)
    .subscribe(data => {
      if (data.success) {
        this.router.navigate(['/login']);
      }
       else{
        this.router.navigate(['/register']);
       }
      }
    );

    this.register =  new Register();
  }

}
