import { Component, OnInit } from '@angular/core';
import { LoginService } from '../service/login.service';
import { Register } from '../model/register';
import { routerNgProbeToken } from '@angular/router/src/router_module';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  loginUser : Register =  new Register();

  constructor(private loginService : LoginService, private router: Router) { }

  ngOnInit() {
  }

  onloginSubmit(){

    this.loginService.loginUser(this.loginUser)
    .subscribe(data => {
      if (data.success) {
        alert('login ok');
        localStorage.setItem("jwtToken", data.token);

        this.router.navigate(['/dashboard']);
      }
       else{
        alert('login failure');
       }
      }
    );

    this.loginUser =  new Register();

  }
}
