import { Injectable } from "@angular/core";
import { CanActivate, Router } from "@angular/router";

@Injectable()
export class AuthGuardComponent implements CanActivate {
  constructor(private router: Router) {}

  canActivate() {
    if (window.localStorage.getItem("jwtToken")) {
      return true;
    } else {
      this.router.navigate(["/login"]);
      return false;
    }
  }
}
