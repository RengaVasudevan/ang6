import { Component, OnInit } from '@angular/core';
import { Recipe } from '../recipe.model';

@Component({
  selector: 'app-recipe-list',
  templateUrl: './recipe-list.component.html',
  styleUrls: ['./recipe-list.component.css']
})
export class RecipeListComponent implements OnInit {
recipes: Recipe[] =[
  new Recipe('Test Recipe','Test description for recipe','https://i.ndtvimg.com/i/2017-08/payasam_650x400_71504098136.jpg?downsize=650:400&output-quality=70&output-format=webp'),
  new Recipe('Test Recipe','Test description for recipe','https://i.ndtvimg.com/i/2017-08/payasam_650x400_71504098136.jpg?downsize=650:400&output-quality=70&output-format=webp')
];
  constructor() { }

  ngOnInit() {
  }

}
